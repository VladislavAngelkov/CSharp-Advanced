﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CustomDoublyLinkedList
{
    public class CustomLinkedList
    {
        public Node Head { get; set; }
        public Node Tail { get; set; }

        public void AddFirst(int element)
        {
            if (this.Head == null)
            {
                Node head = new Node();
                head.Value = element;
                this.Head = head;
                this.Tail = head;
            }
            else
            {
                Node newHead = new Node();
                newHead.Value = element;
                newHead.Next = this.Head;
                this.Head.Previous = newHead;
                this.Head = newHead;
            }
            
        }
        public void AddLast(int element)
        {
            if (this.Head == null)
            {
                Node tail = new Node();
                tail.Value = element;
                this.Head = tail;
                this.Tail = tail;
            }
            else
            {
                Node newTail = new Node();
                newTail.Value = element;
                newTail.Previous = this.Tail;
                this.Tail.Next = newTail;
                this.Tail = newTail;
            }
        }

        public void RemoveFirst()
        {
            Node newHead = this.Head.Next;
            this.Head = newHead;
            this.Head.Previous = null;
        }

        public void RemoveLast()
        {
            Node newTail = this.Tail.Previous;
            this.Tail = newTail;
            this.Tail.Next = null;
        }

        public void ForEach(Action<Node> action)
        {
            Node currNode = this.Head;

            while (currNode!=null)
            {
                action(currNode);
                currNode = currNode.Next;
            }
        }

        public int[] ToArray()
        {
            List<int> list = new List<int>();

            Node currNode = this.Head;

            while (currNode != null)
            {
                list.Add(currNode.Value);
                currNode = currNode.Next;
            }

            int[] result = list.ToArray();
            return result;
        }
    }
}
