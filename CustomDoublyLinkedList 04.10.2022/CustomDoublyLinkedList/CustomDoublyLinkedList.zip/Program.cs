﻿using System;

namespace CustomDoublyLinkedList
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            CustomLinkedList list = new CustomLinkedList();

            list.AddFirst(int.Parse(Console.ReadLine()));
            list.AddFirst(int.Parse(Console.ReadLine()));
            list.AddFirst(int.Parse(Console.ReadLine()));
            list.AddLast(int.Parse(Console.ReadLine()));
            list.AddLast(int.Parse(Console.ReadLine()));
            list.AddLast(int.Parse(Console.ReadLine()));

            Console.WriteLine("------------------------------");

            Node currNode = list.Head;
            while (currNode != null)
            {
                Console.WriteLine(currNode.Value);
                currNode = currNode.Next;
            }

            Console.WriteLine("------------------------------");

            Action<Node> add = node => node.Value++;
            Action<Node> print = node => Console.WriteLine(node.Value);

            list.ForEach(n=>add(n));
            list.ForEach(n => print(n));

            list.RemoveFirst();
            list.RemoveLast();

            int[] array = list.ToArray();

            Console.WriteLine("------------------------------");

            Console.WriteLine(string.Join(" ", array));
        }
    }
}
