﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace CustomCoperator
{
    //public class CustomCopmerator : IComparer<int>
    //{
    //    public int Compare( int x, int y)
    //    {
    //        int result = 0;
    //        if (x%2 == 0 && y%2 == 0)
    //        {
    //            result = x - y;
    //        }
    //        else if (x % 2 != 0 && y % 2 != 0)
    //        {
    //            result = x - y;
    //        }
    //        else if (x%2 == 0 && y%2 != 0)
    //        {
    //            result = -1;
    //        }
    //        else
    //        {
    //            result = 1;
    //        }

    //        return result;
    //    }
    //}
}
